package Main;

import Logica.*;
import Modelo.DNI;

public class Main {

	public static final String ANSI_GREEN = "\u001B[32m";
	public static final String ANSI_BLACK = "\u001B[30m";

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		pruebaDNI();
		pruebaAltaSocio();
		pruebaAltaLibro();
		pruebaAltaPrestamo();
		pruebaVerPrestamo();
		pruebaEliminarLibro();
	}

	private static void pruebaEliminarLibro() {
		// TODO Auto-generated method stub
		System.out.println(ANSI_BLACK + "**************************************************");
		System.out.println(ANSI_BLACK + "\nPrueba eliminar libro");
		Biblioteca b = new Biblioteca();
		cargarDatos(b);

		// eliminar el libro 444-444
		b.eliminarLibro_("444-444");
		System.out.println(ANSI_BLACK + b.listarDatos());

		// libro no encontrado
		b.eliminarLibro_("xxx-xxx");

		b.eliminarLibro_("111-111");

		try {
			System.out.println(ANSI_BLACK + b.verPrestamoSocio("11111111A"));
			System.out.println(ANSI_BLACK + b.verPrestamoSocio("22222222B"));
		} catch (Exception e) {
			System.err.println("Error: " + e.getMessage());
		}

	}

	private static void pruebaVerPrestamo() {
		// TODO Auto-generated method stub
		System.out.println(ANSI_BLACK + "**************************************************");
		System.out.println(ANSI_BLACK + "\nPrueba ver prestamo");
		Biblioteca b = new Biblioteca();
		cargarDatos(b);

		try {
			System.out.println(ANSI_BLACK + b.verPrestamoSocio("11111111A"));
		} catch (Exception e) {
			System.err.println("Error: " + e.getMessage());
		}

		// dni no encontrado
		try {
			System.out.println(b.verPrestamoSocio("99999999A"));
		} catch (Exception e) {
			System.err.println("Error: " + e.getMessage());
		}
	}

	private static void pruebaAltaPrestamo() {
		// TODO Auto-generated method stub
		System.out.println(ANSI_BLACK + "**************************************************");
		System.out.println(ANSI_BLACK + "\nPrueba alta prestamo");
		Biblioteca b = new Biblioteca();
		cargarDatos(b);

		// dni incorrecto
		try {
			b.añadirPrestamo("XXXX", "111-111", "10/05/2024");
		} catch (Exception e) {
			System.err.println("Error: " + e.getMessage());
		}

		// dni no encontrado
		try {
			b.añadirPrestamo("999999999A", "111-111", "10/05/2024");
		} catch (Exception e) {
			System.err.println("Error: " + e.getMessage());
		}

		// isbn no encontrado
		try {
			b.añadirPrestamo("11111111A", "XXX-XXX", "10/05/2024");
		} catch (Exception e) {
			System.err.println("Error: " + e.getMessage());
		}

	}

	private static void pruebaAltaSocio() {
		// TODO Auto-generated method stub
		System.out.println(ANSI_BLACK + "**************************************************");
		System.out.println(ANSI_BLACK + "\nPrueba alta Socio");
		Biblioteca b = new Biblioteca();
		cargarDatos(b);
		System.out.println(ANSI_BLACK + b.listarDatos());

		// socio duplicado
		try {
			b.añadirSocio(new DNI("11111111A"), "socio1", "111-111-111");
		} catch (Exception e) {
			System.err.println("Error: " + e.getMessage());
		}

	}

	private static void pruebaAltaLibro() {
		// TODO Auto-generated method stub
		System.out.println(ANSI_BLACK + "**************************************************");
		System.out.println(ANSI_BLACK + "\nPrueba alta socio");
		Biblioteca b = new Biblioteca();
		cargarDatos(b);
		System.out.println(ANSI_BLACK + b.listarDatos());

		// libro duplicado
		try {
			b.añadirLibro(1, "111-111", "titulo1", "autor1");
		} catch (Exception e) {
			System.err.println("Error: " + e.getMessage());
		}
	}

	private static void pruebaDNI() {
		System.out.println(ANSI_BLACK + "**************************************************");
		System.out.println(ANSI_BLACK + "\nPrueba dni");
		// TODO Auto-generated method stub

		// dni correcto
		try {
			DNI dni = new DNI("11111111A");
		} catch (Exception e) {
			System.err.println(
					"Error: " + e.getMessage());
		}

		// error en letra
		try {
			DNI dni = new DNI("111111111");
		} catch (Exception e) {
			System.err.println(
					"Error: " + e.getMessage());
		}
		// error en numero
		try {
			DNI dni = new DNI("1111111AA");
		} catch (Exception e) {
			System.err.println(
					"Error: " + e.getMessage());
		}
		// error en longitud
		try {
			DNI dni = new DNI("1111A");
		} catch (Exception e) {
			System.err.println(
					"Error: " + e.getMessage());
		}

	}

	public static void cargarDatos(Biblioteca b) {
		try {
			b.añadirLibro(1, "111-111", "titulo1", "autor1");
			b.añadirLibro(2, "222-222", "titulo2", "autor2");
			b.añadirLibro(3, "333-333", "titulo3", "autor3");
			b.añadirLibro(4, "444-444", "titulo4", "autor4");

			b.añadirSocio(new DNI("11111111A"), "socio1", "111-111-111");
			b.añadirSocio(new DNI("22222222B"), "socio2", "222-222-222");
			b.añadirSocio(new DNI("33333333C"), "socio3", "333-333-333");
			b.añadirSocio(new DNI("44444444D"), "socio4", "444-444-444");

			b.añadirPrestamo("11111111A", "111-111", "10/05/2024");
			b.añadirPrestamo("11111111A", "222-222", "11/05/2024");
			b.añadirPrestamo("11111111A", "333-333", "12/05/2024");
			b.añadirPrestamo("22222222B", "111-111", "20/05/2024");
			b.añadirPrestamo("22222222B", "222-222", "21/05/2024");
			b.añadirPrestamo("22222222B", "222-222", "22/05/2024");
			b.añadirPrestamo("22222222B", "333-333", "23/05/2024");
			b.añadirPrestamo("33333333C", "222-222", "22/05/2024");
			b.añadirPrestamo("33333333C", "333-333", "23/05/2024");
		} catch (Exception e) {
			System.err.println("Error: " + e.getMessage());
		}
	}

}
