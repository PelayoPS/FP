package Excepciones;

public class ExamenExcepcion extends Exception {

    public ExamenExcepcion(String string) {
        super(string);
    }

}
