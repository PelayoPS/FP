package Logica;

import java.util.*;

import Excepciones.ExamenExcepcion;
import Modelo.*;

public class Biblioteca {

	// hashmap socios clave dni
	private Map<DNI, Socio> socios;

	// tree set libros ISBN clave
	private Set<Libro> libros;

	public Biblioteca() {
		socios = new HashMap<>();
		libros = new TreeSet<>();
	}

	public void añadirSocio(DNI dniP, String nombre, String telefono) throws ExamenExcepcion{
		Socio socio = new Socio(dniP, nombre, telefono);
		// no se permiten dos socios con mismo dni
		if (socios.containsKey(dniP)) {
			throw new ExamenExcepcion("Ya existe un socio con ese DNI");
		} else {
			socios.put(dniP, socio);
		}
	}

	public void añadirLibro(int codigo, String ISBN, String titulo, String autor) throws ExamenExcepcion {
		Libro libro = new Libro(codigo, ISBN, titulo, autor);
		// no se permiten dos libros con mismo ISBN
		if (libros.contains(libro)) {
			throw new ExamenExcepcion("Ya existe un libro con ese ISBN");
		} else {
			libros.add(libro);
		}
	}

	public void añadirPrestamo(String dniP, String ISBN, String fecha) throws ExamenExcepcion {
		Socio socio = socios.get(new DNI(dniP));
		// get libro from set
		for(Libro l : libros){
			if(l.getISBN().equals(ISBN)){
				// add prestamo to socio
				socio.getPrestamos().add(new Prestamo(l.getISBN(), fecha));
			}
		
		}
	}

	public String listarDatos() {
		String datos = "";
		// list socios
		datos += "SOCIOS \n";
		for (Socio s : socios.values()) {
			datos += s.toString() + "\n";
		}
		// list libros
		datos += "LIBROS \n";
		for (Libro l : libros) {
			datos += l.toString() + "\n";
		}
		// list prestamos
		datos += "PRESTAMOS \n";
		for (Socio s : socios.values()) {
			for (Prestamo p : s.getPrestamos()) {
				datos += p.toString() + "\n";
			}
		}
		return datos;
	}

	public String verPrestamoSocio(String dniP) throws ExamenExcepcion {
		Socio socio = socios.get(new DNI(dniP));
		String prestamos = "";
		for (Prestamo p : socio.getPrestamos()) {
			prestamos += p.toString() + "\n";
		}
		return prestamos;
	}

	public void eliminarLibro_(String ISBN) {
		// remove libro from set if not empty
		if(!libros.isEmpty()){
			for (Libro libro : libros) {
				if (libro.getISBN().equals(ISBN)) {
					libros.remove(libro);
					return;
				}	
			}
		}

		
	}
}
