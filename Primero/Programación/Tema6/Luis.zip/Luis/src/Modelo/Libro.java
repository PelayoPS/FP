package Modelo;

public class Libro
	implements Comparable{

	// atributos
	private int codigo;
	private String ISBN;
	private String titulo;
	private String autor;

	public Libro(int codigo, String iSBN, String titulo, String autor) {
		this.codigo = codigo;
		ISBN = iSBN;
		this.titulo = titulo;
		this.autor = autor;
	}

	// usa el ISBN como clave diferenciadora
	@Override
	public int hashCode() {
		return ISBN.hashCode();
	}

	// usa el ISBN como clave diferenciadora
	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (!(obj instanceof Libro))
			return false;
		Libro other = (Libro) obj;
		return ISBN.equals(other.ISBN);
	}

	public String getISBN() {
		return ISBN;
	}

	@Override
	public int compareTo(Object arg0) {
		Libro l = (Libro) arg0;
		return ISBN.compareTo(l.getISBN());
	}

	@Override
	public String toString() {
		return "Libro [codigo=" + codigo + ", ISBN=" + ISBN + ", titulo=" + titulo + ", autor=" + autor + "]";
	}
	
	
	
	
}
