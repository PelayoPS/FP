package Modelo;

import java.util.Objects;

import Excepciones.ExamenExcepcion;

public class DNI {
	private String dni;

	public DNI(String dniParam) throws ExamenExcepcion {
		comprobarDni(dniParam);
		this.dni = dniParam;
	}

	private void comprobarDni(String dniParam) throws ExamenExcepcion {
		// formato dni 11111111A
		if (dniParam.length() != 9) {
			throw new ExamenExcepcion("Error: El DNI debe tener 9 caracteres");
		}

		// comprobar que los 8 primeros caracteres son números
		for (int i = 0; i < 8; i++) {
			if (!Character.isDigit(dniParam.charAt(i))) {
				throw new ExamenExcepcion("Error: Los 8 primeros caracteres deben ser números");
			}
		}

		// comprobar que el último caracter es una letra
		if (!Character.isLetter(dniParam.charAt(8))) {
			throw new ExamenExcepcion("Error: El último caracter debe ser una letra");
		}
	}

	// methods needed to be key of a hashmap
	@Override
	public int hashCode() {
		return Objects.hash(dni);
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (!(obj instanceof DNI))
			return false;
		DNI other = (DNI) obj;
		return Objects.equals(dni, other.dni);
	}

	@Override
	public String toString() {
		return dni;
	}

}
