package Modelo;

import java.util.LinkedList;
import java.util.List;

public class Socio {

	// atributos
	private DNI dni;
	private String nombre;
	private String telefono;	
	private LinkedList<Prestamo> prestamos;

	// constructor

	public Socio(DNI dni, String nombre, String telefono) {
		this.dni = dni;
		this.nombre = nombre;
		this.telefono = telefono;
		this.prestamos = new LinkedList<>();
	}


	// getters y setters
	public LinkedList<Prestamo> getPrestamos() {
		return prestamos;
	}

	// toString
	@Override
	public String toString() {
		return "Socio [dni=" + dni + ", nombre=" + nombre + ", telefono=" + telefono + ", prestamos=" + prestamos + "]";
	}

	
}
