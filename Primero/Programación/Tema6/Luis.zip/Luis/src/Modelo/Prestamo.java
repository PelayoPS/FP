package Modelo;

public class Prestamo {

	// atributos
	private String ISBN;
	private String fechaAlquiler; // aaaa/mm/dd

	public Prestamo(String iSBN, String fechaAlquiler) {
		ISBN = iSBN;
		this.fechaAlquiler = fechaAlquiler;
	}

	@Override
	public String toString() {
		return "Prestamo [ISBN=" + ISBN + ", fechaAlquiler=" + fechaAlquiler + "]";
	}

}
