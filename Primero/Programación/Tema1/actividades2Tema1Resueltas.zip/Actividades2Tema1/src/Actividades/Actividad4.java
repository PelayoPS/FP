package Actividades;

import java.util.Scanner;

public class Actividad4 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		/*
		 * Calcular media redondeada de 3 números que pedimos al usuario
		 */
		Scanner keyboard = new Scanner(System.in);
		System.out.println("Introduce el primer número");
		float num1 = keyboard.nextFloat();
		System.out.println("Introduce el segundo número");
		float num2 = keyboard.nextFloat();
		System.out.println("Introduce el tercer número");
		float num3 = keyboard.nextFloat();
		float mean = (num1+num2+num3)/3;
		System.out.printf("Media: %.2f", mean);
		keyboard.close();
	}
}
