package Actividades;

import java.util.Scanner;

public class Actividad6 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		/*
		 * Calcular la raíz cuadrada de un número que pediremos por teclado,
		 * en caso de ser negativo informar de que la operación no es posible
		 */
		Scanner keyboard = new Scanner(System.in);
		System.out.println("Introduce el número");
		float num = keyboard.nextFloat();
		if(num < 0) {
			System.err.println("No se puede hacer la raíz porque el número es negativo");
		} else {
			System.out.printf("Raíz: %.2f", Math.sqrt(num));
		}
		
		keyboard.close();
	}
}
