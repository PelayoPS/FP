package Actividades;

import java.util.Scanner;

public class Actividad14 {

	public static void main(String[] args) {
		//Determinar las cifras de un número
		Scanner keyboard = new Scanner(System.in);
		System.out.println("Introduce un número");
		int value = keyboard.nextInt();
		int result = (value+"").length();
		System.out.printf("%d tiene %d cifras", value, result);
		keyboard.close();
	}
}
