package Actividades;

import java.util.GregorianCalendar;
import java.util.Scanner;

public class Actividad7 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		/*
		 * Determinar si un año pedido por teclado es bisiesto
		 */
		Scanner keyboard = new Scanner(System.in);
		System.out.println("Introduce el año");
		int year = keyboard.nextInt();
		GregorianCalendar calendar = new GregorianCalendar();
		if (calendar.isLeapYear(year)) {
			System.out.println("El año es bisiesto");
		} else {
			System.out.println("El año no es bisiesto");
		}
		
		keyboard.close();
	}
}
