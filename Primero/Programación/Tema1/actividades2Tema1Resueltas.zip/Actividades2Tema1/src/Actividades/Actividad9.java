package Actividades;

import java.util.Scanner;

public class Actividad9 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		/*
		 * Leídos dos números por teclado restar al mayor el menor
		 */
		Scanner keyboard = new Scanner(System.in);
		System.out.println("Introduce el primer número");
		float num = keyboard.nextFloat();
		System.out.println("Introduce el segundo número");
		float num1 = keyboard.nextFloat();
		float result = Math.max(num, num1) - Math.min(num, num1);
		System.out.printf("Resultado de restar %.2f-%.2f = %.2f",
				Math.max(num, num1),
				Math.min(num, num1),
				result);
		keyboard.close();
	}
}
