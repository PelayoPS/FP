package Actividades;

import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

public class Actividad12 {

	public static void main(String[] args) {
		Scanner keyboard = new Scanner(System.in);
		List<Integer> ints = new ArrayList<Integer>();
		int num = 0;
		for(int i = 0; i < 5; i++) {
			System.out.println("Introduce el primer número");
			num = keyboard.nextInt();
			ints.add(num);
		}
		keyboard.close();
		ints.sort(null);
		for(int i = 0; i<ints.size()-1;i++) {
			if(ints.get(i+1) - ints.get(i) != 1) {
				System.out.println("No son números consecutivos");
				System.exit(0);
			}
		}
		System.out.println("Son números consecutivos");
		
	}
}
