package Actividades;

import java.util.Scanner;

public class Actividad10 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		/*
		 * Leídos dos números por teclado restar al mayor el menor
		 */
		Scanner keyboard = new Scanner(System.in);
		System.out.println("Introduce la temperatura en grados");
		float degrees = keyboard.nextFloat();
		float farenheir = ((9/5)*degrees)+32;
		System.out.printf("Resultado %.2f C -> %.2f F", degrees, farenheir);
		
		keyboard.close();
		
	}
}
