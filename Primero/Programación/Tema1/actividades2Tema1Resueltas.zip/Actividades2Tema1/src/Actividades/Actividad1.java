package Actividades;

import java.util.Scanner;

public class Actividad1 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		/*
		 * Calcular la superficie y el perímetro de un cuadrado cuyo lado
		 * pediremos por teclado
		 */
		Scanner keyboard = new Scanner(System.in);
		System.out.println("Introduce el lado del cuadrado");
		float value = keyboard.nextFloat();
		System.out.printf("Superficie: %.2f, Perímetro: %.2f", value*value,4*value);
		keyboard.close();
	}

}
