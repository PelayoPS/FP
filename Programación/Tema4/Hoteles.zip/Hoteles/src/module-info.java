/**
 * 
 */
/**
 * 
 */
module Hoteles {
	requires junit;
}