package model;

public enum Role {
    TOP,
    JUNGLE,
    MID,
    ADC,
    SUPPORT
}
