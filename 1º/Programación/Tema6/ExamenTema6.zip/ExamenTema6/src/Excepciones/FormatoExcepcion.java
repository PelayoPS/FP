package Excepciones;

public class FormatoExcepcion extends Exception {

    public FormatoExcepcion(String mensaje) {
        super(mensaje);
    }

}
