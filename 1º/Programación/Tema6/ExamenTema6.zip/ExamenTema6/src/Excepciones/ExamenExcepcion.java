package Excepciones;

public class ExamenExcepcion extends Exception {
        
        public ExamenExcepcion(String mensaje) {
            super(mensaje);
        }

}
