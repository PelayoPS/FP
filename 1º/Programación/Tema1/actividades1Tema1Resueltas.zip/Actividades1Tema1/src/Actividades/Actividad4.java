package Actividades;

public class Actividad4 {

	public static void main(String[] args) {
		int x = 5;
		int y = 0;
		boolean z;
		//ver valores finales
		y = x - 2;
		x = y * 2 + 1;
		z = (x > (y - 5));
		System.out.printf("Valores: x = %d, y = %d, z = %s", x,y,z);
	}
}
