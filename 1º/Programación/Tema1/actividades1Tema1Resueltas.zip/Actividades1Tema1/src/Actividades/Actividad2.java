package Actividades;

public class Actividad2 {
	public static void main(String[] args) {
		int A = 3;
		int B = 4;
		int C = 0;
		//ver valores finales tras operar
		C = A + 2*B;
		C = C + B;
		B = C - A;
		System.out.printf("Valores: A = %d, B = %d, C = %d", A,B,C);
	}
}
