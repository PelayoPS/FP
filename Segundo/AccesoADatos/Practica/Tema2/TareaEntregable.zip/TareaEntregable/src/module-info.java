/**
 * 
 */
/**
 * @author pelayo
 *
 */
module TareaEntregable {
	requires org.junit.jupiter.api;
    requires java.sql;
}