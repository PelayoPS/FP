package src.excepciones;

public class AutorNoEncontradoException extends Exception {
    public AutorNoEncontradoException(String mensaje) {
        super(mensaje);
    }
}
