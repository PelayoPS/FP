package src.excepciones;

public class AutorRepetidoException extends Exception {
    public AutorRepetidoException(String mensaje) {
        super(mensaje);
    }
}
