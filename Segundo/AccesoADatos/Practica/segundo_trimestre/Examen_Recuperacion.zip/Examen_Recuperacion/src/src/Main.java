package src;

public class Main {

    public static void main(String[] args) {
        DGT dgt = new DGT();
        dgt.leerDatos();
        dgt.listConductores();
        dgt.listNoPuntos();
        dgt.saveConductores();
    }

}
