from src.main.main import main

if __name__ == "__main__":
    """
    Punto de entrada de la aplicación.

    Llama a la función principal `main` para iniciar la ejecución del programa.
    """
    main()
