import psycopg2
from database_setup import setup
from datetime import date
from log import logger


def main():
    my_logger = logger.get_logger()
    # Variables de configuración
    user1 = input("Introduce el nombre de usuario de la base de datos: ")
    password1 = input("Introduce la contraseña de la base de datos: ")

    # Configuración de la base de datos
    if not setup(user1, password1):
        my_logger.error("Error al configurar la base de datos")
        return
    else:
        my_logger.info("Base de datos configurada correctamente")
        

if __name__ == "__main__":
    main()