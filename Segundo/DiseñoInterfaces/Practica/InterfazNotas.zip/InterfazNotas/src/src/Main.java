package src;

public class Main {

	public static void main(String[] args) {
		VentanaPrincipal ventana = new VentanaPrincipal("Notas");
		ventana.setVisible(true);

	}

}
