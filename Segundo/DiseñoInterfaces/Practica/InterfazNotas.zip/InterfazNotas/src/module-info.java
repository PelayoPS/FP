/**
 * 
 */
/**
 * 
 */
module InterfazNotas {
	requires java.desktop;
}