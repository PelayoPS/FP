/**
 * 
 */
/**
 * 
 */
module Examen {
    requires java.desktop;
}